var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/random-symbol-replace.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/random-symbol-replace.js":
/*!**************************************!*\
  !*** ./src/random-symbol-replace.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils */ "./src/utils.js");


 // documentation: https://developer.sketchapp.com/reference/api/

/* harmony default export */ __webpack_exports__["default"] = (function () {
  //查看是否选中相关项目
  var currentDoc = sketch_dom__WEBPACK_IMPORTED_MODULE_1___default.a.getSelectedDocument();
  if (!currentDoc) currentDoc = sketch_dom__WEBPACK_IMPORTED_MODULE_1___default.a.getDocuments()[0];
  var selectedLayers = currentDoc.selectedLayers; //返回一个set对象

  var selectedCount = selectedLayers.length;

  if (selectedCount === 0) {
    return sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("请选择控件或者含有控件的画板");
  } else {
    Object(_utils__WEBPACK_IMPORTED_MODULE_2__["symbolsReplace"])(selectedLayers.layers);
  }
});

/***/ }),

/***/ "./src/utils.js":
/*!**********************!*\
  !*** ./src/utils.js ***!
  \**********************/
/*! exports provided: getRandomSymbol, symbolsReplace, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRandomSymbol", function() { return getRandomSymbol; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "symbolsReplace", function() { return symbolsReplace; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_1__);
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }


 // documentation: https://developer.sketchapp.com/reference/api/

function getRandomSymbol(symbols) {
  var length = symbols.length;
  var randomIndex = Math.floor(Math.random() * length);
  var symbol = symbols[randomIndex]; //第一次随机命中控件
  //如控件名字“body/5@0.5” @0.5是稀缺值
  //根据命中控件稀缺性再计算随机一次，降低稀有控件的出现概率
  //1. 从名字中获得组件稀缺值

  var probability = 1; //默认是1，必然出现

  var scarcity = symbol.name.match(/@\d+(\.\d+)$/);
  if (scarcity) probability = parseFloat(scarcity[1]); //2.根据命中控件稀缺值再随机一次

  if (Math.random() <= probability) {
    if (scarcity) {
      sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("\u547D\u4E2D\u7A00\u7F3A\u63A7\u4EF6".concat(symbol.name, ",\u51FA\u73B0\u6982\u7387").concat(1 / (length + 1) * probability));
    }

    return symbol;
  } else {
    //未命中再来一次
    return getRandomSymbol(symbols);
  }
}
function symbolsReplace(collections) {
  // 处理选中的控件
  var collectionsCount = collections.length;
  if (!Array.isArray(collections)) return;
  if (collectionsCount === 0) return;
  var symbolMasters = [];

  var _iterator = _createForOfIteratorHelper(collections),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var symbolObj = _step.value;

      //判断选择类型，如果是symbol则直接替换, 如果是Layer是画板 则替换画板内的symbol
      if (symbolObj.type === 'Artboard' || symbolObj.type === 'Group') {
        var layers = symbolObj.layers;
        symbolsReplace(layers);
        continue;
      }

      if (symbolObj.type === 'SymbolInstance') {
        (function () {
          //找到组件原生体 symbolMaster
          var symbolMaster = symbolObj.master,
              symbolId = symbolObj.symbolId;
          var fullName = symbolMaster.name; //例如：body/5@0.5 “/”是命名空间的分组，@0.5是稀缺性，在随机个数之上再乘以0.5的稀缺性系数
          //找到命名空间下的兄弟组件
          //1.获得名字和命名空间
          //2.查找兄弟控件

          var nameArray = fullName.split('/');
          var lastName = nameArray.pop();
          var pathName = nameArray.join('/') + '/';
          var siblingSymbols = sketch_dom__WEBPACK_IMPORTED_MODULE_1___default.a.find("SymbolMaster,[name^=\"".concat(pathName, "\"]"));
          var symbolIndex = siblingSymbols.findIndex(function (symbol) {
            return symbol.symbolId === symbolId;
          });
          siblingSymbols.splice(symbolIndex, 1); //对当前的控件进行随机替换操作

          var length = siblingSymbols.length;

          if (length > 0) {
            var symbolToReplace = getRandomSymbol(siblingSymbols);
            symbolObj.symbolId = symbolToReplace.symbolId;
            symbolMasters.push(symbolToReplace);
          } else {// console.log(`该${pathName}下只有1个${lastName}控件，无法连续替换`)
          }
        })();
      }
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  return symbolMasters;
}
/* harmony default export */ __webpack_exports__["default"] = ({
  symbolsReplace: symbolsReplace,
  getRandomSymbol: getRandomSymbol
});

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__random-symbol-replace.js.map